import java.util.*;

public class InventoryManagementSystem {
    
    private Map<String, Product> inventory;

    public InventoryManagementSystem() {
        inventory = new HashMap<>();
    }

    public void addProduct(Product product){

        inventory.put(product.getProductId(), product);
    }

    public void updateProduct(Product product){
        if(inventory.containsKey(product.getProductId())){

            inventory.put(product.getProductId(), product);
        }
        else{
            System.out.println("Product Not Present");
        }

    }

    public void deleteProduct(String productId){
        if(inventory.containsKey(productId)){

            inventory.remove(productId);
        }
        else{
            System.out.println("Product not found");
        }
        
    }

    public void displayAllProducts(){
        
        for(Product product : inventory.values()){
            System.out.println(product);
        }
    }

    public static void main(String[] args) {
        InventoryManagementSystem ims = new InventoryManagementSystem();

        ims.addProduct(new Product("P001", "Laptop", 10, 1500.00));
        ims.addProduct(new Product("P002", "Smartphone", 20, 800.00));

        System.out.println("All Products:");
        ims.displayAllProducts();

        ims.updateProduct(new Product("P001", "Gaming Laptop", 5, 2000.00));

        System.out.println("\nAll Products after update:");
        ims.displayAllProducts();

        ims.deleteProduct("P002");

        System.out.println("\nAll Products after deletion:");
        ims.displayAllProducts();
    }
}
