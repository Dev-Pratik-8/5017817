
public class LibraryManagementSystem {
    Book[] books;
    int size;

    public LibraryManagementSystem(int capacity) {
        books = new Book[capacity];
        size = 0;
    }

    public void addBook(Book book) {
        if (size < books.length) {
            books[size] = book;
            size++;
        } else {
            System.out.println("Library is full.");
        }
    }

    public Book linearSearchByTitle(String title) {
        
        for (int i = 0; i < size; i++) {
            if (books[i].getTitle().equalsIgnoreCase(title)) {
                return books[i];
            }
        }
        return null;
    }

    public Book binarySearchByTitle(String title) {

        //Assuming Array is sorted
        int left = 0;
        int right = size - 1;

        while (left <= right) {
            int mid = left + (right - left) / 2;
            int comparison = books[mid].getTitle().compareToIgnoreCase(title);

            if (comparison == 0) {
                return books[mid];
            } else if (comparison < 0) {
                left = mid + 1;
            } else {
                right = mid - 1;
            }
        }
        return null;
    }

    public void displayBooks() {
        for (int i = 0; i < size; i++) {
            System.out.println(books[i]);
        }
    }

    public static void main(String[] args) {
        LibraryManagementSystem lms = new LibraryManagementSystem(10);

        
        lms.addBook(new Book("B1", "Java Programming", "Author A"));
        lms.addBook(new Book("B2", "Python Programming", "Author B"));
        lms.addBook(new Book("B3", "Data Structures", "Author C"));

        
        System.out.println("\nAll Books:");
        lms.displayBooks();

        // Linear search
        Book book1 = lms.linearSearchByTitle("Python Programming");
        System.out.println("\nFound book using Linear Search: " + (book1 != null ? book1 : "Not Found"));

        // Binary search
        Book book2 = lms.binarySearchByTitle("Java Programming");
        System.out.println("\nFound book using Binary Search: " + (book2 != null ? book2 : "Not Found"));
    }
}
