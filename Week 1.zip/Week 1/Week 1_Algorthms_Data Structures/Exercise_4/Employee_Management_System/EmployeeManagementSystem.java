public class EmployeeManagementSystem {
    private Employee[] employees;
    private int size;
    private int capacity;

    public EmployeeManagementSystem(int capacity) {
        this.capacity = capacity;
        employees = new Employee[capacity];
        size = 0;
    }

    public void addEmployee(Employee employee) {
        if (size < capacity) {
            employees[size] = employee;
            size++;
        } else {
            System.out.println("Array is full. Cannot add more employees.");
        }
    }

    public Employee searchEmployee(String employeeId) {
        for (int i = 0; i < size; i++) {
            if (employees[i].getEmployeeId().equals(employeeId)) {
                return employees[i];
            }
        }
        return null;
    }

    public void deleteEmployee(String employeeId) {
        for (int i = 0; i < size; i++) {
            if (employees[i].getEmployeeId().equals(employeeId)) {
                // Shift all elements to the left
                for (int j = i; j < size - 1; j++) {
                    employees[j] = employees[j + 1];
                }
                employees[size - 1] = null;
                size--;
                return;
            }
        }
        System.out.println("Employee not found.");
    }

    public void traverseEmployees() {
        for (int i = 0; i < size; i++) {
            System.out.println(employees[i]);
        }
    }

    public static void main(String[] args) {
        EmployeeManagementSystem ems = new EmployeeManagementSystem(5);

        
        ems.addEmployee(new Employee("E1", "Rohan", "Manager", 80000));
        ems.addEmployee(new Employee("E2", "Preeti", "Developer", 60000));
        ems.addEmployee(new Employee("E3", "Harry", "Designer", 50000));

        
        System.out.println("\nAll Employees:");
        ems.traverseEmployees();

        
        Employee emp = ems.searchEmployee("E2");
        if (emp != null) {
            System.out.println("\nFound Employee: " + emp);
        } else {
            System.out.println("\nEmployee not found.");
        }

        
        ems.deleteEmployee("E1");

        
        System.out.println("\nAll Employees after deletion:");
        ems.traverseEmployees();
    }
}