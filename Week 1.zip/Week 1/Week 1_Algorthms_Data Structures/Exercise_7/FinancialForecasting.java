public class FinancialForecasting {

    
    public static double calculateFutureValue(double currentValue, double growthRate, int periods) {
        
        if (periods == 0) {
            return currentValue;
        }
        
        return calculateFutureValue(currentValue * (1 + growthRate), growthRate, periods - 1);
    }

    public static void main(String[] args) {
        double initialValue = 1000.0;
        double annualGrowthRate = 0.05;
        int numberOfYears = 10;

        double futureValue = calculateFutureValue(initialValue, annualGrowthRate, numberOfYears);
        System.out.println("Future Value after " + numberOfYears + " years: " + futureValue);
    }
}
