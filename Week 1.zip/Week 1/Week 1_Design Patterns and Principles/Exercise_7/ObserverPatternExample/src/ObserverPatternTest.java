public class ObserverPatternTest {
    public static void main(String[] args) {
        StockMarket stockMarket = new StockMarket();

        StockClient client1 = new StockClient("Telusko");
        StockClient client2 = new StockClient("Durgesh");

        stockMarket.registerObserver(client1);
        stockMarket.registerObserver(client2);

        stockMarket.setStockPrice(100.00);
        stockMarket.setStockPrice(101.50);

        stockMarket.deregisterObserver(client1);
        stockMarket.setStockPrice(102.00);
    }
}
