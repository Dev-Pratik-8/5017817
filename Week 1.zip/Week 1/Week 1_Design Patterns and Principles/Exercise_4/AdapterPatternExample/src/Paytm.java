public class Paytm {
    public void payUsingPaytm(double amount) {
        System.out.println("Processing payment of Rupees " + amount + " through Paytm.");
    }
}