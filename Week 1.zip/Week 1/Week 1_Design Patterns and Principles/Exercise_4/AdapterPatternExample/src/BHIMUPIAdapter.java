public class BHIMUPIAdapter implements PaymentProcessor {
    private BHIMUPI bhimUPI;

    public BHIMUPIAdapter(BHIMUPI bhimUPI) {
        this.bhimUPI = bhimUPI;
    }

    @Override
    public void processPayment(double amount) {
        bhimUPI.transferUsingUPI(amount);
    }
}