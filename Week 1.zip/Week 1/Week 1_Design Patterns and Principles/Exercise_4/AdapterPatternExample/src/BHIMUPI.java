public class BHIMUPI {
    public void transferUsingUPI(double amount) {
        System.out.println("Processing payment of Rupees " + amount + " through BHIM UPI.");
    }
}