public class AdapterPatternTest {
    public static void main(String[] args) {
    
        Paytm paytm = new Paytm();
        BHIMUPI bhimUPI = new BHIMUPI();

     
        PaymentProcessor paytmAdapter = new PaytmAdapter(paytm);
        PaymentProcessor bhimUPIAdapter = new BHIMUPIAdapter(bhimUPI);

    
        paytmAdapter.processPayment(500.0);
        bhimUPIAdapter.processPayment(1500.0);
    }
}