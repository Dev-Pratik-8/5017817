public class StrategyPatternTest {
    
    public static void main(String[] args) {
        
        PaymentStrategy creditCardPayment = new CreditCardPayment("1111-1111-1111-1111", "Harry");
        PaymentStrategy payPalPayment = new PayPalPayment("Harry@gmail.com");

        PaymentContext paymentContext = new PaymentContext(creditCardPayment);
        paymentContext.executePayment(5000.00);

        paymentContext = new PaymentContext(payPalPayment);
        paymentContext.executePayment(5000.00);

    }
}
