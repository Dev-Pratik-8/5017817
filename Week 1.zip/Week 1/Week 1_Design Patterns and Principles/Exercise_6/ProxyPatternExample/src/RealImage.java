public class RealImage implements Image{

    String fileName;

    public RealImage(String fileName){
        this.fileName = fileName;
        loadFromRemoteServer(fileName);
    }

    void loadFromRemoteServer(String fileName) {
        System.out.println("Loading " + fileName + " from remote server...");
        System.out.println(fileName + " loaded from remote server.");
    }
    @Override
    public void display() {
        System.out.println("Display " + fileName);
    }
}
