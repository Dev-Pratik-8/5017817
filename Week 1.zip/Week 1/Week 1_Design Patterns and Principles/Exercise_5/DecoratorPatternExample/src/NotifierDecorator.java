public class NotifierDecorator implements Notifier{
    
    Notifier wrappednotifier;

    
    public NotifierDecorator(Notifier notifier) {
        wrappednotifier = notifier;
    }


    @Override
    public void send(String message) {
        wrappednotifier.send(message);
    }
}
