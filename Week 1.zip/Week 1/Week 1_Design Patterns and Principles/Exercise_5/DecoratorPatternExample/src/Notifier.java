public interface Notifier {
    public void send(String message);
}
