public class StudentView {

    public void displayStudentDetails(String studentName, String studentId, String studentGrade){

        System.out.println("Student Name: " + studentName);
        System.out.println("Student Id: " + studentId);
        System.out.println("Student Grade: " + studentGrade);
    }
}
