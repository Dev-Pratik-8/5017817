public class SingletonPatternTest {
    public static void main(String[] args) {
        
        
        Logger logger1 = Logger.getInstance();
        Logger logger2 = Logger.getInstance();


        System.out.println("HashCode of logger1: " + logger1.hashCode());
        System.out.println("HashCode of logger2: " + logger2.hashCode());

        if (logger1 == logger2) {
            System.out.println("Singleton Pattern is being followed");
        } else {
            System.out.println("Singleton Pattern is broken");
        }
    }
}
